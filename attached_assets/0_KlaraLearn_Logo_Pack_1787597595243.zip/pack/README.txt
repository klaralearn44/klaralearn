KlaraLearn Logo Pack
====================

Brand colors
  Navy   #10223E   (primary text / mark)
  Teal   #1E9E93   ("Learn" + book)
  Coral  #F4674A   (accent dot)

Files
  full_transparent.png          Full lockup, transparent bg (1791x476)
  full_transparent_2000w/1000w/500w.png   Pre-sized versions
  full_on_white.png             Full lockup on white
  full_white_on_navy.png        White version on navy (dark backgrounds)
  full_mono_white/black/navy.png  Single-color lockups

  icon_transparent.png          K mark only, square, transparent
  icon_on_white.png / icon_white_on_navy.png
  icon_mono_white/black/navy.png
  icon_512/256/180/48/32/16.png App icons & favicons (180 = Apple touch icon)
  favicon.ico                   Multi-size .ico (16-64px)

  wordmark_transparent.png      Text only, no mark
  wordmark_mono_white/black/navy.png

Usage tips
  - Use mono_white on photos or dark backgrounds; mono_navy or full color on light.
  - Keep clear space around the logo of at least the height of the "K".
  - Don't stretch, recolor partially, or place the color version on busy backgrounds.
